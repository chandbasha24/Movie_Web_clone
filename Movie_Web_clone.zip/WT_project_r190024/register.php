<?php
  session_start();
  include 'connection.php';
  $name = $_POST["name"];
  $email = $_POST["email"];
  $password = $_POST["password"];
  
  $sql = "INSERT INTO $table (name, email, password) VALUES ('$name', '$email', '$password');";
  $resultQuery = mysqli_query($conn,$sql);

  if ($resultQuery) {
    $_SESSION['success'] = true;
    header("Location: success.html");
    exit();
    
  } else {
    $_SESSION['error'] = true;
    header("Location: login.html");
    exit();
    
  }

mysqli_close($conn);
?>
