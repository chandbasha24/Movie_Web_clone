<?php
include 'connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$email = $_POST["email"];
$password = $_POST["password"];

  $sql = "SELECT * FROM $table WHERE email = '$email'";
  $result = mysqli_query($conn,$sql);

  
  $rowcheck = mysqli_num_rows($result);
  if ($rowcheck>0) {
       
    if ($result) {
      
      session_start();
      $_SESSION["user_email"] = $user["email"];
      $_SESSION["user_password"] = $user["password"];
     
      header("Location: dashboard.php");
        } 
     
  }else {
      
    echo "<h1>Email is incorrect</h1>";
   }
  
  mysqli_close($conn);
}
header("Location: index.html");
?>
